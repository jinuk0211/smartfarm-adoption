Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class SmartfarmFonts {
 [DllImport("gdi32.dll", CharSet = CharSet.Unicode)] public static extern int AddFontResourceW(string path);
 [DllImport("user32.dll", SetLastError = true)] public static extern IntPtr SendMessageTimeout(IntPtr window, uint message, IntPtr wParam, IntPtr lParam, uint flags, uint timeout, out IntPtr result);
}
"@
$fontTarget = Join-Path $env:LOCALAPPDATA 'Microsoft/Windows/Fonts'
$fontRegKey = 'HKCU:/Software/Microsoft/Windows NT/CurrentVersion/Fonts'
New-Item -ItemType Directory -Force -Path $fontTarget | Out-Null
New-Item -Path $fontRegKey -Force | Out-Null
foreach ($face in @(@{File='Jua-Regular.ttf';Name='Jua Regular (TrueType)'},@{File='GowunDodum-Regular.ttf';Name='Gowun Dodum Regular (TrueType)'})) {
  $destination = Join-Path $fontTarget $face.File
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot $face.File) -Destination $destination -Force
  New-ItemProperty -Path $fontRegKey -Name $face.Name -Value $destination -PropertyType String -Force | Out-Null
  [SmartfarmFonts]::AddFontResourceW($destination) | Out-Null
}
$fontNoticeResult = [IntPtr]::Zero
[SmartfarmFonts]::SendMessageTimeout([IntPtr]0xffff, 0x001D, [IntPtr]::Zero, [IntPtr]::Zero, 2, 2000, [ref]$fontNoticeResult) | Out-Null
Write-Output 'Jua and Gowun Dodum installed for the current Windows user. Reopen PowerPoint if it was already running.'
