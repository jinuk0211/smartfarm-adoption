# 스마트팜 기획서 글꼴

- **Jua (주아체)**: 제목과 큰 숫자에 사용한 둥근 글꼴입니다.
- **Gowun Dodum (고운돋움)**: 설명과 표에 사용한 글꼴입니다.

## 다른 컴퓨터에서 PPT를 열 때

1. `Jua-Regular.ttf`, `GowunDodum-Regular.ttf`를 각각 더블클릭합니다.
2. **설치**를 누릅니다. 관리자 권한 없이 현재 사용자에게 설치할 수 있습니다.
3. PowerPoint가 이미 켜져 있었다면 종료 후 다시 엽니다.

Windows에서는 이 폴더의 `install-fonts.ps1`을 실행해 두 글꼴을 한 번에 현재 사용자에게 설치할 수도 있습니다.
이 패키지는 **별도 글꼴 파일**입니다. PPT 내부에 글꼴이 포함되었다는 뜻은 아닙니다.

## 출처와 사용 허가

두 글꼴은 SIL Open Font License 1.1로 배포되며, 함께 제공한 원문 라이선스가 적용됩니다.

- Jua: https://github.com/google/fonts/tree/main/ofl/jua
- Gowun Dodum: https://github.com/google/fonts/tree/main/ofl/gowundodum

폰트 원본을 수정하지 않았습니다. 파일별 버전·SHA-256·임베딩 플래그는 `font-manifest.json`에 있습니다.
